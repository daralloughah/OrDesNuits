/* =========================================================
   RÉGLAGES DU SITE — le seul fichier à modifier à la main
   (plus tard, ces valeurs viendront de l'espace gérant)
   ========================================================= */

export const CONTACT = {
  whatsapp: "33600000000",   // ton numéro au format international, sans le +
  snapchat: "ordesnuits",    // ton pseudo Snapchat
};

/* Offre 3 achetés, le 4e offert : désactivée (remplacée par les prix par lots
   réglés produit par produit dans le Salon privé). Mettre true pour la réactiver. */
export const OFFER = { active: false, buy: 3 };

/* Langues proposées. `cur` = devise affichée pour cette langue. */
export const LANGS = [
  { code: "fr",    file: "fr", html: "fr",    name: "Français",      region: "France",          cur: "EUR", locale: "fr-FR" },
  { code: "en-US", file: "en", html: "en-US", name: "English",       region: "United States",   cur: "USD", locale: "en-US" },
  { code: "en-GB", file: "en", html: "en-GB", name: "English",       region: "United Kingdom",  cur: "GBP", locale: "en-GB" },
  { code: "ar",    file: "ar", html: "ar",    name: "العربية",        region: "الإمارات",         cur: "AED", locale: "ar-AE", rtl: true },
  { code: "es",    file: "es", html: "es",    name: "Español",       region: "España",          cur: "EUR", locale: "es-ES" },
  { code: "pt",    file: "pt", html: "pt-BR", name: "Português",     region: "Brasil",          cur: "BRL", locale: "pt-BR" },
  { code: "ru",    file: "ru", html: "ru",    name: "Русский",       region: "Россия",          cur: "RUB", locale: "ru-RU" },
  { code: "de",    file: "de", html: "de",    name: "Deutsch",       region: "Deutschland",     cur: "EUR", locale: "de-DE" },
  { code: "zh",    file: "zh", html: "zh",    name: "中文",           region: "中国",             cur: "CNY", locale: "zh-CN" },
  { code: "ja",    file: "ja", html: "ja",    name: "日本語",         region: "日本",             cur: "JPY", locale: "ja-JP" },
  { code: "ko",    file: "ko", html: "ko",    name: "한국어",         region: "대한민국",          cur: "KRW", locale: "ko-KR" },
];

/* Taux indicatifs : 1 € = … (à automatiser avec Supabase) */
export const RATES = { EUR: 1, USD: 1.10, GBP: 0.86, AED: 4.04, BRL: 6.10, RUB: 95, CNY: 7.85, JPY: 165, KRW: 1500 };

/* Où trouver le catalogue (aujourd'hui un fichier, demain Supabase) */
export const DATA_URL = "data/catalogue.json";

/* =========================================================
   SUPABASE — colle ici l'URL du projet et la clé publique
   (Project Settings → API : "Project URL" et "anon / publishable key").
   Ces deux valeurs sont PUBLIQUES par conception : la sécurité
   est assurée par les règles RLS de la base.
   ⚠️ Ne mets JAMAIS ici la clé "service_role" / "secret".
   Laisse vide pour rester en mode aperçu (données sur l'appareil).
   ========================================================= */
export const SUPABASE = {
  url: "https://vmhqkdsoasfnicxnhtnk.supabase.co",
  anonKey: "sb_publishable_AC3GvOcrNyKvv6_X6uS5eA_wxlcon9i",
};

/* Édition numérotée : les coffrets à partir de « min » pièces portent le numéro
   de la commande (à reporter à la main sur le coffret). active: false pour retirer. */
export const EDITION = { active: true, min: 24 };

/* Boutique : livraison (offerte dès freeFrom €) et emballage cadeau.
   En ligne, ce sont les valeurs du réglage « shop » de Supabase qui comptent. */
export const SHOP = { shipFee: 5.90, freeFrom: 49, giftFee: 3.90 };
